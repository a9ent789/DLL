﻿//Tecumseh McMullin

//Declaring libraries
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Media;
using System.Reflection;
using System.Windows.Forms;

//Declaring namespace
namespace Website_Login
{
    //Main class for the website form
    public partial class Website : Form
    {
        //Constructor for the Website class
        public Website()
        {
            //Creating an instance of the UserControl1 from the Login_Forms assembly
            var ObjectIntro = new Login_Forms.UserControl1();
            // Load the UserControl from the Login Forms assembly
            Assembly assembly = Assembly.LoadFrom("Login Forms.dll");
            // Get the type of the UserControl from the assembly
            Type controlType = assembly.GetType("Login_Forms.UserControl1");

            // If the control type is found and it is a UserControl, create an instance and add it to the form
            if (controlType != null && typeof(UserControl).IsAssignableFrom(controlType))
            {
                // Create an instance of the UserControl and set its properties
                UserControl controlInstance = (UserControl)Activator.CreateInstance(controlType);
                // Set the docking style of the UserControl to fill the parent container to help make it seemless
                controlInstance.Dock = DockStyle.Fill;
                // Add the UserControl instance to the form's controls
                this.Controls.Add(controlInstance);
            }
            // Initialize the form and set its start position
            Form form = new Form();
            // Initialize the components of the form
            InitializeComponent();
            
        }

        // Event handler for when the form loads
        private void Website_Load(object sender, EventArgs e)
        {

        }

        // Event handler for when the label is clicked
        private void button1_Click(object sender, EventArgs e)
        {
            // Create a new SoundPlayer instance and load the specified WAV file
            SoundPlayer player = new SoundPlayer("C:\\Users\\video\\source\\repos\\Website Login\\Songs\\song1.wav");
            player.Load();
            player.Play();
        }

        // Event handlers for the buttons to play different sound files
        private void button2_Click(object sender, EventArgs e)
        {
            // Create a new SoundPlayer instance and load the specified WAV file
            SoundPlayer player = new SoundPlayer("C:\\Users\\video\\source\\repos\\Website Login\\Songs\\song2.wav");
            player.Load();
            player.Play();
        }

        // Event handler for the third button to play a different sound file
        private void button3_Click(object sender, EventArgs e)
        {
            // Create a new SoundPlayer instance and load the specified WAV file
            SoundPlayer player = new SoundPlayer("C:\\Users\\video\\source\\repos\\Website Login\\Songs\\song5.wav");
            player.Load();
            player.Play();
        }

        // Event handler for the fourth button to play another sound file
        private void button4_Click(object sender, EventArgs e)
        {
            // Create a new SoundPlayer instance and load the specified WAV file
            SoundPlayer player = new SoundPlayer("C:\\Users\\video\\source\\repos\\Website Login\\Songs\\song4.wav");
            player.Load();
            player.Play();
        }

        // Event handler for the fifth button to play yet another sound file
        private void button5_Click(object sender, EventArgs e)
        {
            // Create a new SoundPlayer instance and load the specified WAV file
            SoundPlayer player = new SoundPlayer("C:\\Users\\video\\source\\repos\\Website Login\\Songs\\song5.wav");
            player.Load();
            player.Play();
        }

        // Event handler for the sixth button to play a different sound file
        private void button6_Click(object sender, EventArgs e)
        {
            // Create a new SoundPlayer instance and load the specified WAV file
            SoundPlayer player = new SoundPlayer("C:\\Users\\video\\source\\repos\\Website Login\\Songs\\Mans.wav");
            player.Load();
            player.Play();
        }
    }
}
