﻿//Tecumseh McMullin

//Declaring libraries
using Login_Forms;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Declaring namespace
namespace Simulation
{
    //Main class for the home form
    public partial class Home : Form
    {
        //Constructor for the Home class
        public Home()
        {
            //Creating an instance of the UserControl1 from the Login_Forms assembly
            var ObjectIntro = new Login_Forms.UserControl1();
            Assembly assembly = Assembly.LoadFrom("Login Forms.dll");
            Type controlType = assembly.GetType("Login_Forms.UserControl1");

            //If the control type is found and it is a UserControl, create an instance and add it to the form
            if (controlType != null && typeof(UserControl).IsAssignableFrom(controlType))
            {
                //Create an instance of the UserControl and set its properties
                UserControl controlInstance = (UserControl)Activator.CreateInstance(controlType);
                controlInstance.Dock = DockStyle.Fill;
                this.Controls.Add(controlInstance);
            }
            //Initialize the form and set its start position
            Form form = new Form();

            // Initialize the components of the form
            InitializeComponent();
            // Set the start position of the form to the center of the screen
            this.StartPosition = FormStartPosition.CenterScreen;
        }
        //list box function
        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //Event handler for when the form loads
        private void Form1_Load(object sender, EventArgs e)
        {
            

        }

        //Event handler for when the label is clicked
        private void label1_Click(object sender, EventArgs e)
        {

        }

        //Event handler for when the text box text changes
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        //Event handler for when the calculate button is clicked
        private void Calculate_Click_1(object sender, EventArgs e)
        {
            //Retrieve the names from the text boxes
            string name1 = textBox13.Text;
            string name2 = textBox14.Text;
            string name3 = textBox15.Text;
            string name4 = textBox16.Text;
            string name5 = textBox17.Text;
            string name6 = textBox18.Text;

            //declare variables for the stacks and totals
            int stack1;
            int totalA1;

            //Do the alculation for the first stack and total
            if (int.TryParse(textBox1.Text, out stack1) && int.TryParse(textBox2.Text, out totalA1))
            {
                label15.Text = Convert.ToString(totalA1 / stack1);
            }
            else
            {
                label15.Text = string.Empty;
            }

            //declare variables for the second stack and total
            int stack2;
            int totalA2;

            //Do the calculation for the second stack and total
            if (int.TryParse(textBox4.Text, out stack2) && int.TryParse(textBox3.Text, out totalA2))
            {
                label14.Text = Convert.ToString(totalA2 / stack2);
            }
            else
            {
                label14.Text = string.Empty;
            }

            //declare variables for the third stack and total
            int stack3;
            int totalA3;

            if (int.TryParse(textBox6.Text, out stack3) && int.TryParse(textBox5.Text, out totalA3))
            {
                label13.Text = Convert.ToString(totalA3 / stack3);
            }
            else
            {
                label13.Text = string.Empty;
            }

            //declare variables for the fourth stack and total
            int stack4;
            int totalA4;

            //Do the calculation for the fourth stack and total

            if (int.TryParse(textBox8.Text, out stack4) && int.TryParse(textBox7.Text, out totalA4))
            {
                label12.Text = Convert.ToString(totalA4 / stack4);
            }
            else
            {
                label12.Text = string.Empty;
            }


            //declare variables for the fifth stack and total
            int stack5;
            int totalA5;

            //Do the calculation for the fifth stack and total
            if (int.TryParse(textBox10.Text, out stack5) && int.TryParse(textBox9.Text, out totalA5))
            {
                label11.Text = Convert.ToString(totalA5 / stack5);
            }
            else
            {
                label11.Text = string.Empty;
            }

            //declare variables for the sixth stack and total
            int stack6;
            int totalA6;

            //Do the calculation for the sixth stack and total
            if (int.TryParse(textBox12.Text, out stack6) && int.TryParse(textBox11.Text, out totalA6))
            {
                label10.Text = Convert.ToString(totalA6 / stack6);
            }
            else
            {
                label10.Text = string.Empty;
            }

            //Set the text of the labels to the names entered in the text boxes
            label4.Text = name1;
            label5.Text = name2;
            label6.Text = name3;
            label7.Text = name4;
            label8.Text = name5;
            label9.Text = name6;


        }

        //Event handler for when the exit button is clicked
        private void githubLinkButton_Click(object sender, EventArgs e)
        {
            //Open the GitHub page in the default web browser
            System.Diagnostics.Process.Start("https://github.com/a9ent789");
        }
    }
}